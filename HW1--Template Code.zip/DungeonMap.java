
/* Contains the Rooms in the dungeon 
and logic for Player movement */
public class DungeonMap {
	/* Rooms in the dungeon */
    private Room[][] rooms;

    /* Reference to the Player in the dungeon */
    private Player player;

    /* Initializes the rooms and shared Player reference */
    public DungeonMap (int rows, int columns, Player player){

    }

    /* Displays the dungeon's rooms, walls,
    and player's current location */
    public void print() {

    }
	
	//TODO: method(s) to move player
}
