
public class Main {
	/* Entry point of the application */
    public static void main(String[] args) {

    }
}